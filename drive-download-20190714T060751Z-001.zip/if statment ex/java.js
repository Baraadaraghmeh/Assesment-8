/* 1. Write a JavaScript program that accept two integers and
 * display the larger.Go to the editor */
function larger(){
var num1=3 ;
var num2=5; 
if (num1>num2){
  return num1 ; 
}
else{
  return num2 ; 
}

}
  
  
 /******* End Your Code ********* */

/* 2. Write a JavaScript conditional statement to find the sign
 of product of three numbers. Display an alert box with the 
 specified sign. Go to the editor 
Sample numbers : 3, -7, 2 
Output : The sign is - */
function sign(x){
var num ;  
if (num>0){
  return "pos";
} else if (num<0){
    return  "neg";
  }
}



  
 /******* End Your Code ********* */

/* 3. Write a JavaScript conditional statement to sort three numbers. Display an alert box to show the result. Go to the editor 
Sample numbers : 0, -1, 4 
Output : 4, 0, -1 */
function larg(){
var num1 ;
var num2 ; 
var num3 ; 
if (num1 > num2 && num1 > num3){
return num1 ; 
}
  else if (num2>num1 && num2>num3){

    return num2 ; 
}
     else 
      return num3 ; 
} 
     
       
  

 /******* End Your Code ********* */


/*4. Write a JavaScript conditional statement to find the largest of five numbers. 
Display an alert box to show the result. Go to the editor 
Sample numbers : -5, -2, -6, 0, -1 
Output : 0 */
function largest(){

var number1 ;
var number2 ;
var number3 ;
var number4 ;
var number5 ;
 if (number1>number2 && number1>number3 && number1>number4 && number1>number5){

  return number1 ;
}
else if (number2>number1 && number2>number3 && number2>number4 && number2>number5){
 

return number2;
}

else if (number3>number1 && number3>number2 && number3>number4 && number3>number5){

return number3 ;
 }

else if (number4>number1 && number4>number2 && number4>number3 && number4>number5){
return "The largest number = " + number4 ; 
  }
 
else{
return number5 ;   
}

}

  
 /******* End Your Code ********* */

 /* 5.Fix the if statement to display "Hello World" if x is greater than y, otherwise alert "Goodbye".*/
/******* Start Your Code *********/
function sentence(){
  var x ;
  var y ; 
  if (x>y){
return "Hello world";
}
else
{
return"Goodbye"; 
}

}
 /******* End Your Code ********* */


/*write the if statement to display "Hello World" if x is greater than y.*/
/******* Start Your Code *********/
  
 /******* End Your Code ********* */
